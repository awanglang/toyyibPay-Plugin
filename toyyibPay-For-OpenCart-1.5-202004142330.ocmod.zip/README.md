# ToyyibPay-for-OpenCart 1.5.x
Accept Payment using ToyyibPay for OpenCart 1.5.x

# Plugin Version History
* 1.0.0 Build 201906181200 : Release dev & prod version
* 1.0.1 Build 201912311535 : Fix roblem cart not empty after payment
* 1.1.0 Build 202003112350 : Add create log file, API environment setting, Payment Channel Setting, and change error display.
* 1.2.0 Build 202004142330 : Edit length & add new setting

# Installation
1. Download and extract to installation directory
2. Install
3. Configure API Key, Collection ID
4. Hola, you are done!

